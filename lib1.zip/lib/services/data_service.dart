import 'package:flutter/material.dart';
import '../models/data_models.dart';
import '../models/user_model.dart';

class DataService {
  static final DataService _instance = DataService._internal();
  factory DataService() => _instance;

  // Move the initialization here, in the private constructor
  DataService._internal() {
    _initializeData();
  }

  // Current user data
  String? _currentUserId;
  UserType? _currentUserType;

  void setCurrentUser(String userId, UserType userType) {
    _currentUserId = userId;
    _currentUserType = userType;
  }

  String? get currentUserId => _currentUserId;
  UserType? get currentUserType => _currentUserType;

  // Sample Data
  late final List<Student> _students;
  late final List<Teacher> _teachers;
  late final List<SchoolClass> _classes;
  late final List<Subject> _subjects;
  late final List<TimetableEntry> _timetable;
  late final List<Grade> _grades;
  late final List<Attendance> _attendance;
  late final List<Assignment> _assignments;
  late final List<Message> _messages;
  late final List<SchoolEvent> _events;
  late final List<Document> _documents;

  void _initializeData() {
    _initializeSubjects();
    _initializeTeachers();
    _initializeClasses();
    _initializeStudents();
    _initializeTimetable();
    _initializeGrades();
    _initializeAttendance();
    _initializeAssignments();
    _initializeMessages();
    _initializeEvents();
    _initializeDocuments();
  }

  void _initializeSubjects() {
    _subjects = [
      Subject(id: '1', name: 'Matematika', shortName: 'MAT', color: Colors.blue),
      Subject(id: '2', name: 'Český jazyk', shortName: 'ČJ', color: Colors.red),
      Subject(id: '3', name: 'Anglický jazyk', shortName: 'AJ', color: Colors.green),
      Subject(id: '4', name: 'Fyzika', shortName: 'FYZ', color: Colors.purple),
      Subject(id: '5', name: 'Chemie', shortName: 'CHE', color: Colors.orange),
      Subject(id: '6', name: 'Biologie', shortName: 'BIO', color: Colors.teal),
      Subject(id: '7', name: 'Dějepis', shortName: 'DEJ', color: Colors.brown),
      Subject(id: '8', name: 'Zeměpis', shortName: 'ZEM', color: Colors.cyan),
      Subject(id: '9', name: 'Informatika', shortName: 'INF', color: Colors.indigo),
      Subject(id: '10', name: 'Tělesná výchova', shortName: 'TV', color: Colors.amber),
    ];
  }

  void _initializeTeachers() {
    _teachers = [
      Teacher(
        id: 'teacher1',
        firstName: 'Jan',
        lastName: 'Novák',
        email: 'j.novak@skola.cz',
        phone: '+420 123 456 789',
        subjectIds: ['1', '4'], // Matematika, Fyzika
        classIds: ['1a', '2a', '3b', '3c'], // 4 classes now!
        title: 'Mgr.',
      ),
      Teacher(
        id: 'teacher2',
        firstName: 'Marie',
        lastName: 'Svobodová',
        email: 'm.svobodova@skola.cz',
        phone: '+420 234 567 890',
        subjectIds: ['2', '7'],
        classIds: ['2a', '2b'],
        title: 'PhDr.',
      ),
      Teacher(
        id: 'teacher3',
        firstName: 'Petr',
        lastName: 'Dvořák',
        email: 'p.dvorak@skola.cz',
        phone: '+420 345 678 901',
        subjectIds: ['3'],
        classIds: ['2a', '2b', '3a', '3b'],
        title: 'Mgr.',
      ),
      Teacher(
        id: 'teacher4',
        firstName: 'Eva',
        lastName: 'Procházková',
        email: 'e.prochazkova@skola.cz',
        phone: '+420 456 789 012',
        subjectIds: ['5', '6'],
        classIds: ['3a', '3b'],
        title: 'RNDr.',
      ),
    ];
  }

  void _initializeClasses() {
    _classes = [
      SchoolClass(
        id: '1a',
        name: '1.A',
        teacherId: 'teacher1',
        studentIds: ['student13', 'student14', 'student15', 'student18'],
        year: 7,
      ),
      SchoolClass(
        id: '2a',
        name: '2.A',
        teacherId: 'teacher1',
        studentIds: ['student1', 'student2', 'student3', 'student9', 'student10'],
        year: 8,
      ),
      SchoolClass(
        id: '2b',
        name: '2.B',
        teacherId: 'teacher2',
        studentIds: ['student4', 'student5', 'student6'],
        year: 8,
      ),
      SchoolClass(
        id: '3a',
        name: '3.A',
        teacherId: 'teacher3',
        studentIds: [],
        year: 9,
      ),
      SchoolClass(
        id: '3b',
        name: '3.B',
        teacherId: 'teacher4',
        studentIds: ['student7', 'student8', 'student11', 'student12'],
        year: 9,
      ),
      SchoolClass(
        id: '3c',
        name: '3.C',
        teacherId: 'teacher1',
        studentIds: ['student16', 'student17', 'student19'],
        year: 9,
      ),
    ];
  }

  void _initializeStudents() {
    _students = [
      // Class 1.A students (teacher1's youngest class)
      Student(
        id: 'student13',
        firstName: 'Lucie',
        lastName: 'Nováková',
        classId: '1a',
        email: 'l.novakova@student.skola.cz',
        birthDate: DateTime(2011, 4, 10),
        parentEmail: 'novakova.rodic@email.cz',
        parentPhone: '+420 777 888 999',
        address: 'Parková 15, Praha',
      ),
      Student(
        id: 'student14',
        firstName: 'Jan',
        lastName: 'Dvořák',
        classId: '1a',
        email: 'j.dvorak@student.skola.cz',
        birthDate: DateTime(2011, 7, 22),
        parentEmail: 'dvorak.rodic@email.cz',
        parentPhone: '+420 666 555 444',
        address: 'Lesní 20, Praha',
      ),
      Student(
        id: 'student15',
        firstName: 'Eva',
        lastName: 'Malá',
        classId: '1a',
        email: 'e.mala@student.skola.cz',
        birthDate: DateTime(2011, 12, 5),
        parentEmail: 'mala.rodic@email.cz',
        parentPhone: '+420 333 222 111',
        address: 'Školní 33, Praha',
      ),
      Student(
        id: 'student18',
        firstName: 'Tomáš',
        lastName: 'Veselý',
        classId: '1a',
        email: 't.vesely@student.skola.cz',
        birthDate: DateTime(2011, 9, 18),
        parentEmail: 'vesely.rodic@email.cz',
        parentPhone: '+420 444 333 222',
        address: 'Krátká 8, Praha',
      ),

      // Class 2.A students (teacher1's class)
      Student(
        id: 'student1',
        firstName: 'Tomáš',
        lastName: 'Kolář',
        classId: '2a',
        email: 't.kolar@student.skola.cz',
        birthDate: DateTime(2010, 5, 15),
        parentEmail: 'kolar.rodic@email.cz',
        parentPhone: '+420 601 234 567',
        address: 'Hlavní 123, Praha',
      ),
      Student(
        id: 'student2',
        firstName: 'Anna',
        lastName: 'Horáková',
        classId: '2a',
        email: 'a.horakova@student.skola.cz',
        birthDate: DateTime(2010, 3, 22),
        parentEmail: 'horakova.rodic@email.cz',
        parentPhone: '+420 602 345 678',
        address: 'Školní 456, Praha',
      ),
      Student(
        id: 'student3',
        firstName: 'David',
        lastName: 'Černý',
        classId: '2a',
        email: 'd.cerny@student.skola.cz',
        birthDate: DateTime(2010, 8, 10),
        parentEmail: 'cerny.rodic@email.cz',
        parentPhone: '+420 603 456 789',
        address: 'Nová 789, Praha',
      ),
      Student(
        id: 'student9',
        firstName: 'Eliška',
        lastName: 'Nováková',
        classId: '2a',
        email: 'e.novakova@student.skola.cz',
        birthDate: DateTime(2010, 1, 30),
        parentEmail: 'novakova.rodic@email.cz',
        parentPhone: '+420 609 123 456',
        address: 'Parkova 15, Praha',
      ),
      Student(
        id: 'student10',
        firstName: 'Filip',
        lastName: 'Procházka',
        classId: '2a',
        email: 'f.prochazka@student.skola.cz',
        birthDate: DateTime(2010, 6, 18),
        parentEmail: 'prochazka.rodic@email.cz',
        parentPhone: '+420 610 234 567',
        address: 'Lesní 42, Praha',
      ),

      // Class 2.B students
      Student(
        id: 'student4',
        firstName: 'Klára',
        lastName: 'Veselá',
        classId: '2b',
        email: 'k.vesela@student.skola.cz',
        birthDate: DateTime(2010, 12, 3),
        parentEmail: 'vesela.rodic@email.cz',
        parentPhone: '+420 604 567 890',
        address: 'Krásná 321, Praha',
      ),
      Student(
        id: 'student5',
        firstName: 'Martin',
        lastName: 'Svoboda',
        classId: '2b',
        email: 'm.svoboda@student.skola.cz',
        birthDate: DateTime(2010, 7, 18),
        parentEmail: 'svoboda.rodic@email.cz',
        parentPhone: '+420 605 678 901',
        address: 'Dlouhá 654, Praha',
      ),
      Student(
        id: 'student6',
        firstName: 'Jakub',
        lastName: 'Novotný',
        classId: '2b',
        email: 'j.novotny@student.skola.cz',
        birthDate: DateTime(2010, 9, 14),
        parentEmail: 'novotny.rodic@email.cz',
        parentPhone: '+420 606 789 012',
        address: 'Školní 987, Praha',
      ),

      // Class 3.B students
      Student(
        id: 'student7',
        firstName: 'Tereza',
        lastName: 'Svobodová',
        classId: '3b',
        email: 't.svobodova@student.skola.cz',
        birthDate: DateTime(2009, 4, 25),
        parentEmail: 'svobodova.rodic@email.cz',
        parentPhone: '+420 607 890 123',
        address: 'Nádražní 654, Praha',
      ),
      Student(
        id: 'student8',
        firstName: 'Michal',
        lastName: 'Dvořák',
        classId: '3b',
        email: 'm.dvorak@student.skola.cz',
        birthDate: DateTime(2009, 11, 8),
        parentEmail: 'dvorak.rodic@email.cz',
        parentPhone: '+420 608 901 234',
        address: 'Krásná 321, Praha',
      ),
      Student(
        id: 'student11',
        firstName: 'Viktorie',
        lastName: 'Kratochvílová',
        classId: '3b',
        email: 'v.kratochvilova@student.skola.cz',
        birthDate: DateTime(2009, 2, 12),
        parentEmail: 'kratochvilova.rodic@email.cz',
        parentPhone: '+420 611 345 678',
        address: 'Zahradní 28, Praha',
      ),
      Student(
        id: 'student12',
        firstName: 'Ondřej',
        lastName: 'Krejčí',
        classId: '3b',
        email: 'o.krejci@student.skola.cz',
        birthDate: DateTime(2009, 9, 5),
        parentEmail: 'krejci.rodic@email.cz',
        parentPhone: '+420 612 456 789',
        address: 'Sportovní 73, Praha',
      ),

      // Class 3.C students (teacher1's advanced class)
      Student(
        id: 'student16',
        firstName: 'Petr',
        lastName: 'Horák',
        classId: '3c',
        email: 'p.horak@student.skola.cz',
        birthDate: DateTime(2009, 3, 15),
        parentEmail: 'horak.rodic@email.cz',
        parentPhone: '+420 999 888 777',
        address: 'Nádražní 44, Praha',
      ),
      Student(
        id: 'student17',
        firstName: 'Michaela',
        lastName: 'Krejčí',
        classId: '3c',
        email: 'm.krejci@student.skola.cz',
        birthDate: DateTime(2009, 6, 21),
        parentEmail: 'krejci.rodic@email.cz',
        parentPhone: '+420 111 222 333',
        address: 'Zahradní 55, Praha',
      ),
      Student(
        id: 'student19',
        firstName: 'Štěpán',
        lastName: 'Pokorný',
        classId: '3c',
        email: 's.pokorny@student.skola.cz',
        birthDate: DateTime(2009, 10, 12),
        parentEmail: 'pokorny.rodic@email.cz',
        parentPhone: '+420 555 666 777',
        address: 'Dlouhá 88, Praha',
      ),
    ];
  }

  void _initializeTimetable() {
    _timetable = [
      TimetableEntry(
        id: 'tt1',
        subjectId: '1',
        teacherId: 'teacher1',
        classId: '2a',
        room: '101',
        dayOfWeek: 1,
        period: 1,
        startTime: DateTime(2024, 1, 1, 8, 0),
        endTime: DateTime(2024, 1, 1, 8, 45),
      ),
      TimetableEntry(
        id: 'tt2',
        subjectId: '2',
        teacherId: 'teacher2',
        classId: '2a',
        room: '102',
        dayOfWeek: 1,
        period: 2,
        startTime: DateTime(2024, 1, 1, 8, 55),
        endTime: DateTime(2024, 1, 1, 9, 40),
      ),
      TimetableEntry(
        id: 'tt3',
        subjectId: '3',
        teacherId: 'teacher3',
        classId: '2a',
        room: '103',
        dayOfWeek: 1,
        period: 3,
        startTime: DateTime(2024, 1, 1, 9, 50),
        endTime: DateTime(2024, 1, 1, 10, 35),
      ),
    ];
  }

  void _initializeGrades() {
    _grades = [
      // ===== CLASS 1.A - MATHEMATICS =====
      Grade(id: 'g100', studentId: 'student13', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Základní algebra test', date: DateTime.now().subtract(const Duration(days: 28)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g101', studentId: 'student14', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Základní algebra test', date: DateTime.now().subtract(const Duration(days: 28)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g102', studentId: 'student15', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Základní algebra test', date: DateTime.now().subtract(const Duration(days: 28)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g103', studentId: 'student18', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Základní algebra test', date: DateTime.now().subtract(const Duration(days: 28)), type: GradeType.test, weight: 8.0),

      Grade(id: 'g104', studentId: 'student13', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Domácí úkol - zlomky', date: DateTime.now().subtract(const Duration(days: 22)), type: GradeType.homework, weight: 4.0),
      Grade(id: 'g105', studentId: 'student14', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Domácí úkol - zlomky', date: DateTime.now().subtract(const Duration(days: 22)), type: GradeType.homework, weight: 4.0),
      Grade(id: 'g106', studentId: 'student15', subjectId: '1', teacherId: 'teacher1', value: 4, description: 'Domácí úkol - zlomky', date: DateTime.now().subtract(const Duration(days: 22)), type: GradeType.homework, weight: 4.0),
      Grade(id: 'g107', studentId: 'student18', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Domácí úkol - zlomky', date: DateTime.now().subtract(const Duration(days: 22)), type: GradeType.homework, weight: 4.0),

      // ===== CLASS 1.A - PHYSICS =====
      Grade(id: 'g108', studentId: 'student13', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Úvod do mechaniky', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.test, weight: 7.0),
      Grade(id: 'g109', studentId: 'student14', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Úvod do mechaniky', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.test, weight: 7.0),
      Grade(id: 'g110', studentId: 'student15', subjectId: '4', teacherId: 'teacher1', value: 3, description: 'Úvod do mechaniky', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.test, weight: 7.0),
      Grade(id: 'g111', studentId: 'student18', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Úvod do mechaniky', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.test, weight: 7.0),

      // ===== CLASS 3.C - MATHEMATICS (Advanced) =====
      Grade(id: 'g112', studentId: 'student16', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Pokročilá algebra - maturity', date: DateTime.now().subtract(const Duration(days: 18)), type: GradeType.exam, weight: 10.0),
      Grade(id: 'g113', studentId: 'student17', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Pokročilá algebra - maturity', date: DateTime.now().subtract(const Duration(days: 18)), type: GradeType.exam, weight: 10.0),
      Grade(id: 'g114', studentId: 'student19', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Pokročilá algebra - maturity', date: DateTime.now().subtract(const Duration(days: 18)), type: GradeType.exam, weight: 10.0),

      Grade(id: 'g115', studentId: 'student16', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Integrály a derivace', date: DateTime.now().subtract(const Duration(days: 10)), type: GradeType.test, weight: 9.0),
      Grade(id: 'g116', studentId: 'student17', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Integrály a derivace', date: DateTime.now().subtract(const Duration(days: 10)), type: GradeType.test, weight: 9.0),
      Grade(id: 'g117', studentId: 'student19', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Integrály a derivace', date: DateTime.now().subtract(const Duration(days: 10)), type: GradeType.test, weight: 9.0),

      // ===== CLASS 3.C - PHYSICS (Advanced) =====
      Grade(id: 'g118', studentId: 'student16', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Kvantová mechanika - úvod', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.exam, weight: 10.0),
      Grade(id: 'g119', studentId: 'student17', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Kvantová mechanika - úvod', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.exam, weight: 10.0),
      Grade(id: 'g120', studentId: 'student19', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Kvantová mechanika - úvod', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.exam, weight: 10.0),

      // COMPREHENSIVE DATA FOR STUDENT1 (Tomáš Kolář) - MATHEMATICS
      Grade(id: 'g1', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Písemná práce - kvadratické rovnice', date: DateTime.now().subtract(const Duration(days: 5)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g2', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Domácí úkol - funkce', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.homework, weight: 3.0),
      Grade(id: 'g3', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Ústní zkoušení - geometrie', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g4', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Práce v hodině - procenta', date: DateTime.now().subtract(const Duration(days: 1)), type: GradeType.classwork, weight: 2.0),
      Grade(id: 'g5', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Projekt - statistika', date: DateTime.now().subtract(const Duration(days: 20)), type: GradeType.project, weight: 7.0),
      Grade(id: 'g6', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 4, description: 'Test - zlomky', date: DateTime.now().subtract(const Duration(days: 25)), type: GradeType.test, weight: 6.0),
      Grade(id: 'g7', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Domácí úkol - rovnice', date: DateTime.now().subtract(const Duration(days: 18)), type: GradeType.homework, weight: 3.0),

      // STUDENT1 - PHYSICS
      Grade(id: 'g8', studentId: 'student1', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Laboratorní práce - mechanika', date: DateTime.now().subtract(const Duration(days: 7)), type: GradeType.classwork, weight: 6.0),
      Grade(id: 'g9', studentId: 'student1', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Test - síly a pohyb', date: DateTime.now().subtract(const Duration(days: 14)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g10', studentId: 'student1', subjectId: '4', teacherId: 'teacher1', value: 3, description: 'Ústní zkoušení - energie', date: DateTime.now().subtract(const Duration(days: 21)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g11', studentId: 'student1', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Domácí úkol - výpočty', date: DateTime.now().subtract(const Duration(days: 9)), type: GradeType.homework, weight: 4.0),

      // STUDENT1 - CZECH LANGUAGE
      Grade(id: 'g12', studentId: 'student1', subjectId: '2', teacherId: 'teacher2', value: 1, description: 'Slohová práce - popis osoby', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.project, weight: 7.0),
      Grade(id: 'g13', studentId: 'student1', subjectId: '2', teacherId: 'teacher2', value: 2, description: 'Čtení s porozuměním', date: DateTime.now().subtract(const Duration(days: 3)), type: GradeType.test, weight: 6.0),
      Grade(id: 'g14', studentId: 'student1', subjectId: '2', teacherId: 'teacher2', value: 1, description: 'Ústní projev - referát', date: DateTime.now().subtract(const Duration(days: 11)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g15', studentId: 'student1', subjectId: '2', teacherId: 'teacher2', value: 3, description: 'Gramatika - slovní druhy', date: DateTime.now().subtract(const Duration(days: 6)), type: GradeType.classwork, weight: 4.0),

      // STUDENT1 - ENGLISH
      Grade(id: 'g16', studentId: 'student1', subjectId: '3', teacherId: 'teacher3', value: 1, description: 'Vocabulary test - Unit 5', date: DateTime.now().subtract(const Duration(days: 4)), type: GradeType.test, weight: 6.0),
      Grade(id: 'g17', studentId: 'student1', subjectId: '3', teacherId: 'teacher3', value: 2, description: 'Speaking - My family', date: DateTime.now().subtract(const Duration(days: 13)), type: GradeType.exam, weight: 7.0),
      Grade(id: 'g18', studentId: 'student1', subjectId: '3', teacherId: 'teacher3', value: 1, description: 'Writing - Letter', date: DateTime.now().subtract(const Duration(days: 19)), type: GradeType.project, weight: 6.0),

      // OTHER STUDENTS IN CLASS 2.A - MATHEMATICS (for teacher view)
      Grade(id: 'g19', studentId: 'student2', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Písemná práce - kvadratické rovnice', date: DateTime.now().subtract(const Duration(days: 5)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g20', studentId: 'student2', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Domácí úkol - funkce', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.homework, weight: 3.0),
      Grade(id: 'g21', studentId: 'student2', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Ústní zkoušení - geometrie', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g22', studentId: 'student2', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Práce v hodině - procenta', date: DateTime.now().subtract(const Duration(days: 1)), type: GradeType.classwork, weight: 2.0),
      Grade(id: 'g23', studentId: 'student2', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Projekt - statistika', date: DateTime.now().subtract(const Duration(days: 20)), type: GradeType.project, weight: 7.0),

      Grade(id: 'g24', studentId: 'student3', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Písemná práce - kvadratické rovnice', date: DateTime.now().subtract(const Duration(days: 5)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g25', studentId: 'student3', subjectId: '1', teacherId: 'teacher1', value: 4, description: 'Domácí úkol - funkce', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.homework, weight: 3.0),
      Grade(id: 'g26', studentId: 'student3', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Ústní zkoušení - geometrie', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g27', studentId: 'student3', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Práce v hodině - procenta', date: DateTime.now().subtract(const Duration(days: 1)), type: GradeType.classwork, weight: 2.0),
      Grade(id: 'g28', studentId: 'student3', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Projekt - statistika', date: DateTime.now().subtract(const Duration(days: 20)), type: GradeType.project, weight: 7.0),

      Grade(id: 'g29', studentId: 'student9', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Písemná práce - kvadratické rovnice', date: DateTime.now().subtract(const Duration(days: 5)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g30', studentId: 'student9', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Domácí úkol - funkce', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.homework, weight: 3.0),
      Grade(id: 'g31', studentId: 'student9', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Ústní zkoušení - geometrie', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.exam, weight: 5.0),
      Grade(id: 'g32', studentId: 'student9', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Práce v hodině - procenta', date: DateTime.now().subtract(const Duration(days: 1)), type: GradeType.classwork, weight: 2.0),

      Grade(id: 'g33', studentId: 'student10', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Písemná práce - kvadratické rovnice', date: DateTime.now().subtract(const Duration(days: 5)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g34', studentId: 'student10', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Domácí úkol - funkce', date: DateTime.now().subtract(const Duration(days: 12)), type: GradeType.homework, weight: 3.0),
      Grade(id: 'g35', studentId: 'student10', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Ústní zkoušení - geometrie', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.exam, weight: 5.0),

      // CLASS 2.A - PHYSICS
      Grade(id: 'g36', studentId: 'student2', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Laboratorní práce - mechanika', date: DateTime.now().subtract(const Duration(days: 7)), type: GradeType.classwork, weight: 6.0),
      Grade(id: 'g37', studentId: 'student3', subjectId: '4', teacherId: 'teacher1', value: 3, description: 'Laboratorní práce - mechanika', date: DateTime.now().subtract(const Duration(days: 7)), type: GradeType.classwork, weight: 6.0),
      Grade(id: 'g38', studentId: 'student9', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Laboratorní práce - mechanika', date: DateTime.now().subtract(const Duration(days: 7)), type: GradeType.classwork, weight: 6.0),
      Grade(id: 'g39', studentId: 'student10', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Laboratorní práce - mechanika', date: DateTime.now().subtract(const Duration(days: 7)), type: GradeType.classwork, weight: 6.0),

      Grade(id: 'g40', studentId: 'student2', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Test - síly a pohyb', date: DateTime.now().subtract(const Duration(days: 14)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g41', studentId: 'student3', subjectId: '4', teacherId: 'teacher1', value: 4, description: 'Test - síly a pohyb', date: DateTime.now().subtract(const Duration(days: 14)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g42', studentId: 'student9', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Test - síly a pohyb', date: DateTime.now().subtract(const Duration(days: 14)), type: GradeType.test, weight: 8.0),
      Grade(id: 'g43', studentId: 'student10', subjectId: '4', teacherId: 'teacher1', value: 3, description: 'Test - síly a pohyb', date: DateTime.now().subtract(const Duration(days: 14)), type: GradeType.test, weight: 8.0),

      // CLASS 3.B - MATHEMATICS (Advanced)
      Grade(id: 'g44', studentId: 'student7', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Maturitní test - komplexní čísla', date: DateTime.now().subtract(const Duration(days: 3)), type: GradeType.test, weight: 10.0),
      Grade(id: 'g45', studentId: 'student8', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Maturitní test - komplexní čísla', date: DateTime.now().subtract(const Duration(days: 3)), type: GradeType.test, weight: 10.0),
      Grade(id: 'g46', studentId: 'student11', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Maturitní test - komplexní čísla', date: DateTime.now().subtract(const Duration(days: 3)), type: GradeType.test, weight: 10.0),
      Grade(id: 'g47', studentId: 'student12', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Maturitní test - komplexní čísla', date: DateTime.now().subtract(const Duration(days: 3)), type: GradeType.test, weight: 10.0),

      Grade(id: 'g48', studentId: 'student7', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Projekt - aplikovaná statistika', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.project, weight: 9.0),
      Grade(id: 'g49', studentId: 'student8', subjectId: '1', teacherId: 'teacher1', value: 3, description: 'Projekt - aplikovaná statistika', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.project, weight: 9.0),
      Grade(id: 'g50', studentId: 'student11', subjectId: '1', teacherId: 'teacher1', value: 1, description: 'Projekt - aplikovaná statistika', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.project, weight: 9.0),
      Grade(id: 'g51', studentId: 'student12', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Projekt - aplikovaná statistika', date: DateTime.now().subtract(const Duration(days: 15)), type: GradeType.project, weight: 9.0),

      // CLASS 3.B - PHYSICS (Advanced)
      Grade(id: 'g52', studentId: 'student7', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Laboratorní práce - optika', date: DateTime.now().subtract(const Duration(days: 4)), type: GradeType.classwork, weight: 8.0),
      Grade(id: 'g53', studentId: 'student8', subjectId: '4', teacherId: 'teacher1', value: 2, description: 'Laboratorní práce - optika', date: DateTime.now().subtract(const Duration(days: 4)), type: GradeType.classwork, weight: 8.0),
      Grade(id: 'g54', studentId: 'student11', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Laboratorní práce - optika', date: DateTime.now().subtract(const Duration(days: 4)), type: GradeType.classwork, weight: 8.0),
      Grade(id: 'g55', studentId: 'student12', subjectId: '4', teacherId: 'teacher1', value: 3, description: 'Laboratorní práce - optika', date: DateTime.now().subtract(const Duration(days: 4)), type: GradeType.classwork, weight: 8.0),

      // Additional recent grades for variety
      Grade(id: 'g56', studentId: 'student1', subjectId: '1', teacherId: 'teacher1', value: 2, description: 'Rychlý test - početní operace', date: DateTime.now().subtract(const Duration(days: 2)), type: GradeType.test, weight: 4.0),
      Grade(id: 'g57', studentId: 'student1', subjectId: '4', teacherId: 'teacher1', value: 1, description: 'Referát - obnovitelné zdroje', date: DateTime.now().subtract(const Duration(days: 16)), type: GradeType.project, weight: 6.0),
      Grade(id: 'g58', studentId: 'student1', subjectId: '2', teacherId: 'teacher2', value: 2, description: 'Diktát - pravopis', date: DateTime.now().subtract(const Duration(days: 8)), type: GradeType.test, weight: 5.0),
    ];
  }

  // Add helper methods to the DataService class
  List<SchoolClass> getClassesForTeacher(String teacherId) {
    return _classes.where((c) => c.teacherId == teacherId).toList();
  }

  List<Student> getStudentsForClass(String classId) {
    return _students.where((s) => s.classId == classId).toList();
  }

  List<Grade> getGradesForClassAndSubject(String classId, String subjectId) {
    final classStudents = getStudentsForClass(classId);
    final studentIds = classStudents.map((s) => s.id).toList();
    return _grades.where((g) =>
    studentIds.contains(g.studentId) && g.subjectId == subjectId
    ).toList();
  }

  List<Subject> getSubjectsForTeacher(String teacherId) {
    final teacher = getTeacherById(teacherId);
    if (teacher == null) return [];
    return _subjects.where((s) => teacher.subjectIds.contains(s.id)).toList();
  }

  void _initializeAttendance() {
    _attendance = [
      Attendance(
        id: 'att1',
        studentId: 'student1',
        subjectId: '1',
        date: DateTime.now().subtract(const Duration(days: 1)),
        period: 1,
        type: AttendanceType.present,
        excused: false,
      ),
      Attendance(
        id: 'att2',
        studentId: 'student1',
        subjectId: '2',
        date: DateTime.now().subtract(const Duration(days: 1)),
        period: 2,
        type: AttendanceType.absent,
        note: 'Návštěva lékaře',
        excused: true,
      ),
    ];
  }

  void _initializeAssignments() {
    _assignments = [
      Assignment(
        id: 'assign1',
        title: 'Domácí úkol - kvadratické rovnice',
        description: 'Vyřešte úlohy 1-15 ze strany 42',
        subjectId: '1',
        teacherId: 'teacher1',
        classIds: ['2a'],
        dueDate: DateTime.now().add(const Duration(days: 3)),
        assignedDate: DateTime.now().subtract(const Duration(days: 2)),
        type: AssignmentType.homework,
        attachments: [],
      ),
      Assignment(
        id: 'assign2',
        title: 'Projekt - Můj oblíbený spisovatel',
        description: 'Připravte prezentaci o svém oblíbeném spisovateli',
        subjectId: '2',
        teacherId: 'teacher2',
        classIds: ['2a', '2b'],
        dueDate: DateTime.now().add(const Duration(days: 14)),
        assignedDate: DateTime.now().subtract(const Duration(days: 7)),
        type: AssignmentType.project,
        attachments: ['pokyny.pdf'],
      ),
    ];
  }

  void _initializeMessages() {
    _messages = [
      Message(
        id: 'msg1',
        fromId: 'teacher1',
        toIds: ['student1'],
        subject: 'Konzultace z matematiky',
        content: 'Dobrý den, chtěl bych Vás pozvat na konzultaci z matematiky. Je možné přijít zítra po vyučování?',
        sentDate: DateTime.now().subtract(const Duration(hours: 2)),
        isRead: false,
        type: MessageType.personal,
      ),
      Message(
        id: 'msg2',
        fromId: 'teacher2',
        toIds: ['student1', 'student2', 'student3'],
        subject: 'Zrušení hodiny',
        content: 'Zítra bude zrušena hodina českého jazyka z důvodu nemoci vyučujícího.',
        sentDate: DateTime.now().subtract(const Duration(hours: 5)),
        isRead: true,
        type: MessageType.announcement,
      ),
    ];
  }

  void _initializeEvents() {
    _events = [
      SchoolEvent(
        id: 'event1',
        title: 'Podzimní prázdniny',
        description: 'Dvoudenní prázdniny',
        startDate: DateTime.now().add(const Duration(days: 10)),
        endDate: DateTime.now().add(const Duration(days: 11)),
        location: 'Celá škola',
        type: EventType.holiday,
        targetClassIds: ['2a', '2b', '3a', '3b'],
        organizerId: 'teacher1',
      ),
      SchoolEvent(
        id: 'event2',
        title: 'Exkurze do planetária',
        description: 'Vzdělávací exkurze pro žáky 8. tříd',
        startDate: DateTime.now().add(const Duration(days: 20)),
        endDate: DateTime.now().add(const Duration(days: 20)),
        location: 'Planetárium Praha',
        type: EventType.trip,
        targetClassIds: ['2a', '2b'],
        organizerId: 'teacher4',
      ),
    ];
  }

  void _initializeDocuments() {
    _documents = [
      Document(
        id: 'doc1',
        title: 'Školní řád',
        description: 'Aktuální znění školního řádu',
        fileName: 'skolni_rad_2024.pdf',
        fileType: 'PDF',
        uploadDate: DateTime.now().subtract(const Duration(days: 30)),
        uploaderId: 'teacher1',
        targetClassIds: ['2a', '2b', '3a', '3b'],
        category: DocumentCategory.policy,
      ),
      Document(
        id: 'doc2',
        title: 'Učební osnovy - Matematika',
        description: 'Osnovy pro školní rok 2024/2025',
        fileName: 'osnovy_matematika.pdf',
        fileType: 'PDF',
        uploadDate: DateTime.now().subtract(const Duration(days: 15)),
        uploaderId: 'teacher1',
        targetClassIds: ['2a', '3b'],
        category: DocumentCategory.syllabus,
      ),
    ];
  }

  // Getter methods for accessing data
  List<Student> get students => List.unmodifiable(_students);
  List<Teacher> get teachers => List.unmodifiable(_teachers);
  List<SchoolClass> get classes => List.unmodifiable(_classes);
  List<Subject> get subjects => List.unmodifiable(_subjects);
  List<TimetableEntry> get timetable => List.unmodifiable(_timetable);
  List<Grade> get grades => List.unmodifiable(_grades);
  List<Attendance> get attendance => List.unmodifiable(_attendance);
  List<Assignment> get assignments => List.unmodifiable(_assignments);
  List<Message> get messages => List.unmodifiable(_messages);
  List<SchoolEvent> get events => List.unmodifiable(_events);
  List<Document> get documents => List.unmodifiable(_documents);

  // Helper methods for filtered data
  Student? getCurrentStudent() {
    if (_currentUserType == UserType.student && _currentUserId != null) {
      return _students.firstWhere((s) => s.id == _currentUserId);
    }
    return null;
  }

  Teacher? getCurrentTeacher() {
    if (_currentUserType == UserType.teacher && _currentUserId != null) {
      return _teachers.firstWhere((t) => t.id == _currentUserId);
    }
    return null;
  }

  List<Grade> getGradesForStudent(String studentId) {
    return _grades.where((g) => g.studentId == studentId).toList();
  }

  List<Assignment> getAssignmentsForClass(String classId) {
    return _assignments.where((a) => a.classIds.contains(classId)).toList();
  }

  List<TimetableEntry> getTimetableForClass(String classId) {
    return _timetable.where((t) => t.classId == classId).toList();
  }

  List<Message> getMessagesForUser(String userId) {
    return _messages.where((m) =>
    m.fromId == userId || m.toIds.contains(userId)
    ).toList();
  }

  Subject? getSubjectById(String id) {
    return _subjects.firstWhere((s) => s.id == id);
  }

  Teacher? getTeacherById(String id) {
    return _teachers.firstWhere((t) => t.id == id);
  }

  SchoolClass? getClassById(String id) {
    return _classes.firstWhere((c) => c.id == id);
  }
}
