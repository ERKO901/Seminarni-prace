import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'theme/app_theme.dart';
import 'models/user_model.dart';
import 'services/data_service.dart';

void main() {
  runApp(const MagistryApp());
}

class MagistryApp extends StatefulWidget {
  const MagistryApp({super.key});

  @override
  State<MagistryApp> createState() => _MagistryAppState();
}

class _MagistryAppState extends State<MagistryApp> with WidgetsBindingObserver {
  ThemeMode _themeMode = ThemeMode.system;
  UserType? _userType;
  late bool _systemIsDark;
  final DataService _dataService = DataService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _systemIsDark = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    setState(() {
      _systemIsDark = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
    });
  }

  bool get _effectiveIsDark {
    switch (_themeMode) {
      case ThemeMode.system:
        return _systemIsDark;
      case ThemeMode.light:
        return false;
      case ThemeMode.dark:
        return true;
    }
  }

  void _cycleTheme() {
    setState(() {
      switch (_themeMode) {
        case ThemeMode.system:
          _themeMode = ThemeMode.light;
          break;
        case ThemeMode.light:
          _themeMode = ThemeMode.dark;
          break;
        case ThemeMode.dark:
          _themeMode = ThemeMode.system;
          break;
      }
    });
  }

  void _setUserType(UserType userType) {
    setState(() {
      _userType = userType;
      // Set current user in data service
      if (userType == UserType.student) {
        _dataService.setCurrentUser(DemoUsers.studentId, userType);
      } else {
        _dataService.setCurrentUser(DemoUsers.teacherId, userType);
      }
    });
  }

  void _logout() {
    setState(() {
      _userType = null;
      _dataService.setCurrentUser('', UserType.student); // Clear user
    });
  }

  String get _themeDisplayName {
    switch (_themeMode) {
      case ThemeMode.system:
        return 'Systém';
      case ThemeMode.light:
        return 'Světlý';
      case ThemeMode.dark:
        return 'Tmavý';
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Magistři',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: _themeMode,
      home: _userType == null
          ? LoginScreen(onLogin: _setUserType)
          : DashboardScreen(
        userType: _userType!,
        onLogout: _logout,
        onThemeToggle: _cycleTheme,
        currentThemeMode: _themeMode,
        effectiveIsDark: _effectiveIsDark,
        themeDisplayName: _themeDisplayName,
      ),
    );
  }
}
