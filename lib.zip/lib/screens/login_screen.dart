import 'package:flutter/material.dart';
import '../models/user_model.dart';

class LoginScreen extends StatelessWidget {
  final Function(UserType) onLogin;

  const LoginScreen({super.key, required this.onLogin});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth > 800;
    final cardWidth = isDesktop ? 400.0 : double.infinity;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor.withOpacity(0.8),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              child: Container(
                constraints: BoxConstraints(maxWidth: cardWidth),
                padding: EdgeInsets.symmetric(
                  horizontal: isDesktop ? 0 : 32,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo and Title
                    Container(
                      padding: EdgeInsets.all(isDesktop ? 24 : 32),
                      child: Column(
                        children: [
                          Container(
                            width: isDesktop ? 80 : 120,
                            height: isDesktop ? 80 : 120,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(isDesktop ? 20 : 30),
                            ),
                            child: Icon(
                              Icons.school_outlined,
                              size: isDesktop ? 40 : 60,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: isDesktop ? 16 : 24),
                          Text(
                            'Magistři',
                            style: TextStyle(
                              fontSize: isDesktop ? 28 : 36,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: isDesktop ? 4 : 8),
                          Text(
                            'Demo školního systému',
                            style: TextStyle(
                              fontSize: isDesktop ? 14 : 16,
                              color: Colors.white.withOpacity(0.9),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: isDesktop ? 16 : 32),
                    // Login Options
                    Column(
                      children: [
                        Text(
                          'Vyberte typ účtu',
                          style: TextStyle(
                            fontSize: isDesktop ? 16 : 18,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: isDesktop ? 24 : 32),
                        _buildLoginOption(
                          context: context,
                          title: 'Žák',
                          subtitle: 'Přihlásit se jako žák',
                          icon: Icons.person_outline,
                          onTap: () => onLogin(UserType.student),
                          isDesktop: isDesktop,
                        ),
                        SizedBox(height: isDesktop ? 12 : 16),
                        _buildLoginOption(
                          context: context,
                          title: 'Učitel',
                          subtitle: 'Přihlásit se jako učitel',
                          icon: Icons.person_4_outlined,
                          onTap: () => onLogin(UserType.teacher),
                          isDesktop: isDesktop,
                        ),
                      ],
                    ),
                    SizedBox(height: isDesktop ? 24 : 48),
                    Text(
                      'Demo verze - žádná data nejsou skutečná',
                      style: TextStyle(
                        fontSize: isDesktop ? 11 : 12,
                        color: Colors.white.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginOption({
    required BuildContext context,
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
    required bool isDesktop,
  }) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: EdgeInsets.all(isDesktop ? 16 : 24),
          width: double.infinity,
          child: Row(
            children: [
              Container(
                width: isDesktop ? 40 : 50,
                height: isDesktop ? 40 : 50,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(isDesktop ? 8 : 12),
                ),
                child: Icon(
                  icon,
                  color: Theme.of(context).primaryColor,
                  size: isDesktop ? 20 : 28,
                ),
              ),
              SizedBox(width: isDesktop ? 12 : 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontSize: isDesktop ? 16 : 20,
                      ),
                    ),
                    SizedBox(height: isDesktop ? 2 : 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontSize: isDesktop ? 12 : 14,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: Theme.of(context).primaryColor,
                size: isDesktop ? 16 : 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
